<?php
    $route = 'employees';

?>

<?php $__env->startSection('content'); ?>
    <!-- start container -->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header row justify-content-center centered">
                        <h3>
                            Changing Password
                        </h3>
                    </div>
                    <div class="card-body row justify-content-center centered align-items-center" style="padding: 30px">
                        <form class="col-md-8 col-sm-12" action="<?php echo e(url('resting')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input name="password" type="password"  value="<?php echo e(old('password')); ?>" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="New Password" >
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <center>
                                <input type="submit" class="btn btn-success" style="margin: 15px">
                            </center>
                        </form>
                    </div>
                    <div class="card-footer row justify-content-center centered align-items-center">
                        <a href="<?php echo e(url('home')); ?>" style="cursor: pointer">
                            <button class="btn btn-primary" style="cursor: pointer">
                                Back
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/employee/rest.blade.php ENDPATH**/ ?>