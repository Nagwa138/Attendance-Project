<?php
    $route = 'employees';

?>

<?php $__env->startSection('content'); ?>

    <!-- start container -->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header row justify-content-center centered">
                        <h3>
                            Profile
                        </h3>
                    </div>
                    <div class="card-body row justify-content-center centered align-items-center" style="padding: 30px">
                        <div class="col-md-6 col-sm-12">
                            <span style="font-weight: bold"> Name :</span><br>
                            <span><?php echo e(Auth::user()->name); ?></span><br><br>
                            <span style="font-weight: bold"> E-mail :</span><br>
                            <span><?php echo e(Auth::user()->email); ?></span><br><br>
                            <span style="font-weight: bold"> Department :</span><br>
                            <span><?php echo e($department->name); ?></span><br>
                        </div>
                        <div class="col-md-6 col-sm-12 row justify-content-center centered">
                            <img src="<?php echo e(asset('uploads/users_images/' . Auth::user()->id .'/'. $employee->pic)); ?>">
                        </div>
                    </div>
                    <div class="card-footer row justify-content-center centered align-items-center">
                        <a href="<?php echo e(url('Updating')); ?>" style="margin-right: 20px;cursor: pointer">
                            <button class="btn btn-success" style="cursor: pointer">
                                Edit
                            </button>
                        </a>
                        <a href="<?php echo e(url('home')); ?>" style="margin-right: 20px;cursor: pointer">
                            <button class="btn btn-primary" style="cursor: pointer">
                                Back
                            </button>
                        </a>
                        <a href="<?php echo e(url('rest')); ?>" >
                            Change Password
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end container -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/employee/profile.blade.php ENDPATH**/ ?>