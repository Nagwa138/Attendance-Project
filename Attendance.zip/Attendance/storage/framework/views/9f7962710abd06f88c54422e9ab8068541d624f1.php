


    <footer class="footer">
        <div class="container-fluid">
            <nav>
                <ul class="footer-menu">
                    <li>
                        <a href="#">
                            Home
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Company
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Portfolio
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Blog
                        </a>
                    </li>
                </ul>
                <p class="copyright text-center">
                    ©
                    <script>
                        document.write(new Date().getFullYear())
                    </script>
                    <a href="http://www.creative-tim.com">Creative Tim</a>, made with love for a better web
                </p>
            </nav>
        </div>
    </footer>
</div>


<div class="fixed-plugin">
    <div class="dropdown show-dropdown">
        <a href="#" data-toggle="dropdown">
            <i class="fa fa-cog fa-2x"> </i>
        </a>

        <ul class="dropdown-menu">
			<li class="header-title"> Sidebar Style</li>
            <li class="adjustments-line">
                <a href="javascript:void(0)" class="switch-trigger">
                    <p>Background Image</p>
                    <label class="switch">
                        <input type="checkbox" data-toggle="switch" checked="" data-on-color="primary" data-off-color="primary"><span class="toggle"></span>
                    </label>
                    <div class="clearfix"></div>
                </a>
            </li>
            <li class="adjustments-line">
                <a href="javascript:void(0)" class="switch-trigger background-color">
                    <p>Filters</p>
                    <div class="pull-right">
                        <span class="badge filter badge-black" data-color="black"></span>
                        <span class="badge filter badge-azure" data-color="azure"></span>
                        <span class="badge filter badge-green" data-color="green"></span>
                        <span class="badge filter badge-orange" data-color="orange"></span>
                        <span class="badge filter badge-red" data-color="red"></span>
                        <span class="badge filter badge-purple active" data-color="purple"></span>
                    </div>
                    <div class="clearfix"></div>
                </a>
            </li>
            <li class="header-title">Sidebar Images</li>

            <li class="active">
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="<?php echo e(asset('img/sidebar-1.jpg')); ?>" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="<?php echo e(asset('img/sidebar-3.jpg')); ?>" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="<?php echo e(asset('img/sidebar-4.jpg')); ?>" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="<?php echo e(asset('img/sidebar-5.jpg')); ?>" alt="" />
                </a>
            </li>


            <li class="header-title pro-title text-center">Want more components?</li>


            <li class="header-title" id="sharrreTitle">Thank you for sharing!</li>

            <li class="button-container">
				<button id="twitter" class="btn btn-social btn-outline btn-twitter btn-round sharrre"><i class="fa fa-twitter"></i> · 256</button>
                <button id="facebook" class="btn btn-social btn-outline btn-facebook btn-round sharrre"><i class="fa fa-facebook-square"></i> · 426</button>
            </li>
        </ul>
    </div>
</div>


</body>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!--   Core JS Files   -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/core/popper.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/core/bootstrap.min.js')); ?>" type="text/javascript"></script>

<!--  Plugin for Switches, full documentation here-->
<script src="<?php echo e(asset('js/plugins/bootstrap-switch.js')); ?>"></script>

 <!-- Include this in your blade layout -->
 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


<!--  Notifications Plugin    -->
<script src="<?php echo e(asset('js/plugins/bootstrap-notify.js')); ?>"></script>

<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="<?php echo e(asset('js/light-bootstrap-dashboard.js?v=2.0.0')); ?>" type="text/javascript"></script>

<!-- Light Bootstrap Dashboard DEMO methods, dont include it in your project! -->
<script src="<?php echo e(asset('js/demo.js')); ?>"></script>

<script src="<?php echo e(asset('js/backend.js')); ?>"></script>


<script>
    $(document).ready(function() {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });



    /* using ajax add and edit and delete */

    $('#addUser').submit(function(e) {

        e.preventDefault();
        var formData  = new FormData(jQuery('#addUser')[0]);


         $.ajax({
            url:"<?php echo e(url('admin/user/store')); ?>",
            type:"POST",
            data:formData,
            contentType: false,
            processData: false,
            cache:false,
            success:function(data)
            {


             $("#success").html("<li class='alert alert-success text-center p-1'> Added Success </li>").fadeOut(2000);
                $(".cont-data").prepend(data);
                $('#exampleModal').modal('hide');

            },
            error: function(xhr, status, error) {

                //console.log("XHR => " + xhr + " ERROR => " + error + " STATUS => " + status );

              $("#error").html('');

                $.each(xhr.responseJSON.errors, function(key, item){
                    $("#error").append("<div class= 'alert alert-danger text-center'>"+ item +"</div>");
                });

            }

        });
    });



    $('.deleteUser').click(function(e) {
        e.preventDefault();
        var url = $(this).data('url');

            $.ajax({
                method:'get',
                url:url,
                cache:false,
                success:function(data){

                    $("#error").html("<li class='alert alert-success text-center p-1'> Deleted Success </li>").fadeOut(2000);
                    $("#" + data.id).remove();
                }
            });

    });


    /* end using ajax add and edit and delete */


    /* _____________________________category using ajax add and edit and delete______________________________ */

    $("#addCategory").submit(function(e){
            e.preventDefault();
            var formData  = new FormData(jQuery('#addCategory')[0]);
            // console.log(formData);
            $.ajax({
                url:"<?php echo e(url('admin/category/store')); ?>",
                type:"POST",
                data:formData,
                contentType: false,
                processData: false,
                success:function(dataBack)
                {
                    $("#error").html("<li class='alert alert-success text-center p-1'> Added Success </li>").fadeOut(3000);
                    $(".cont-data").prepend(dataBack);
                    $('#exampleModal').modal('hide');

                }, error: function (xhr, status, error)
                {

                    // console.log(xhr.responseJSON.errors);
                    $.each(xhr.responseJSON.errors,function(key,item)
                    {

                        $("#error").html("<li class='alert alert-danger text-center p-1'>"+ item +" </li>");
                    })
                }
            });

    });

    $(".delete").click(function (e) {
            e.preventDefault();
            var url = $(this).data("route");

            $.ajax({
                method:"get",
                url:url,
                success: function(data)
                {

                    $("#error").html("<li class='alert alert-success text-center p-1'> Deleted Success </li>").fadeOut(3000);
                    $("#" + data.id).remove();
                }
            });

    });


    $(document).on("click",".edit",function(){

        var route = $(this).attr("data-route");

        $.ajax({
            type:"get",
            url:route,
            success:function(data)
            {
                $("#id").val(data.id);
                $("#name").val(data.name);
                $("#font").val(data.font);

            }


        });
    });



    $("#updateCategory").submit(function(e){
        e.preventDefault();

        var formData  = new FormData(jQuery('#updateCategory')[0]);
        var idRow = $("#id").val();

        // console.log(formData);

        $.ajax({
            url:"<?php echo e(url('admin/category/update/')); ?>",
            type:"POST",
            data:formData + idRow,
            contentType: false,
            processData: false,
            success:function(data)
            {
                $("#errorUpdate").html("<li class='alert alert-success text-center p-1'> Edited Success </li>");
                $("#"+idRow).html(data);
                $('#exampleModal2').modal('hide');

            }, error: function (xhr, status, error)
            {

                // console.log(xhr.responseJSON.errors);
                $.each(xhr.responseJSON.errors,function(key,item)
                {

                    $("#errorUpdate").html("<li class='alert alert-danger text-center p-1'>"+ item +" </li>");
                })
            }
        })

    });

    /*_________________________________ End category using ajax add and edit and delete________________________ */


    /* _____________________________Product using ajax add and edit and delete______________________________ */

        $('#addProduct').submit(function(e){
            e.preventDefault();

            var formData = new FormData(jQuery('#addProduct')[0]);

            $.ajax({
                type:'post',
                url:"<?php echo e(url('admin/product/store')); ?>",
                data:formData,
                cache:false,
                processData:false,
                contentType:false,
                success:function(data)
                {
                    $("#error").html("<li class='alert alert-success text-center p-1'> Added Success </li>").fadeOut(3000);
                    $(".cont-data").prepend(data);
                    $('#exampleModal').modal('hide');


                },error: function(xhr, err, status)
                {
                    // console.log(xhr.responseJSON.errors);
                    /*$.each(xhr.responseJSON.errors,function(key,item)
                    {

                        $("#error").html("<li class='alert alert-danger text-center p-1'>"+ item +" </li>");
                    });*/
                }

            });
        });

        $(".deleteProduct").click(function(e){
            e.preventDefault();

            var url = $(this).data('route');

            $.ajax({
                url:url,
                method:"get",
                success: function(data)
                {
                    $("#error").html("<li class='alert alert-success text-center p-1'> Deleted Success </li>").fadeOut(3000);
                    $("#" + data.id).remove();
                }
            });
        });

        $('.editProduct').click(function(e){
            e.preventDefault();

            var url = $(this).data('route');


            $.ajax({
                url:url,
                method:"get",
                dataType:"json",
                success: function(data)
                {
                    $("#id").val(data.id);
                    $("#name").val(data.name);
                    $("#category_id").val(data.category_id);
                    $("#price").val(data.price);
                    $("#sales").val(data.sales);
                    $("#describe").val(data.describe);
                    $("#stock").val(data.stock);
                    $("#addImage").html("<img src='http://127.0.0.1:8000/uploads/products_images/" + data.image  + "' class='photo-user image-preview'>");
                }
            });
        });
    /*_________________________________ End Product using ajax add and edit and delete________________________ */



    //___________________________________SHOW ORDER BY AJAX_____________________________
    //start of cheque
    $(document).on('click', '#show-order', function(e) {
        e.preventDefault();

        $('#loading').css('display', 'flex');

        var url = $(this).data('url');
        var method = $(this).data('method');

        //alert(url  +" "+ method );

        $.ajax({
            url: url,
            method: method,
            success: function(data) {
                $('#loading').css('display', 'none');
                $('#show-chque').empty();
                $('#show-chque').append(data);
            }
        });

    });


    });
</script>

</html>
<?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/Layout/footer.blade.php ENDPATH**/ ?>