<?php $__env->startSection('nav'); ?>


    <li class=" nav-item" style="margin-left:20px">
        <a href="#" class="nav-link "  data-toggle="dropdown">
            <i class="fas fa-bell"></i>
            <?php if(Auth::guard('admin')->check()): ?>
                <span class="notification" id="notification-counter-admin"></span>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->head == 1): ?>
                    <span class="notification" id="notification-counter-head">7</span>
                <?php endif; ?>
                <?php if(Auth::user()->head == 0): ?>
                    <span class="notification" id="notification-counter-user"></span>
                <?php endif; ?>
            <?php endif; ?>

            <span class="d-lg-none">Notification</span>
        </a>
        <ul class="dropdown-menu">
            <?php if(Auth::guard('admin')->check()): ?>
                
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                
            <?php endif; ?>

            <a class="dropdown-item text-primary" data-toggle="modal" data-target="#notificationmodel">
                View All Notifications
            </a>

        </ul>
    </li>


    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->head == 1): ?>

            <li style="list-style:none; margin-left:20px">
                <a class="navbar-link text-dark" href="<?php echo e(url('employees/list')); ?>" >
                    Employees
                </a>
            </li>
            <li style="list-style:none; margin-left:20px">
                <a class="navbar-link text-dark" href="<?php echo e(url('check_out_list')); ?>" >
                    Leaving Requests
                </a>
            </li>
            <li style="list-style:none; margin-left:20px">
                <a class="navbar-link text-dark" href="<?php echo e(route('attendances.create')); ?>" >
                    Attendance Tracked
                </a>
            </li>

        <?php endif; ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <div class="card">
                    <div class="card-header">
                        <h3 style="padding: 20px">Check out Requests</h3>
                    </div>
                    <div class="card-body">
                        <?php if($users->count() > 0): ?>
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Department</th>
                                    <th scope="col">Reason</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if($requests->count() > 0): ?>
                                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($user->id != Auth::user()->id): ?>
                                                <?php if($user->id == $request->user_id): ?>
                                                    <?php if($employees->count() > 0): ?>
                                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($employee->user_id == $user->id): ?>
                                                                <?php if($employee->department_id == $department): ?>
                                                                    <tr>
                                                                        <td><?php echo e($index +1); ?></td>
                                                                        <td><?php echo e($user->name); ?></td>
                                                                        <td>
                                                                            <?php echo e($department_data->name); ?>

                                                                        </td>
                                                                        <td>
                                                                            <?php echo e($request->reason); ?>

                                                                        </td>
                                                                        <td>
                                                                            <a href="<?php echo e(url('requests/update/'. $request->id , 1 )); ?>" style="cursor: pointer;font-size: 20px">
                                                                                <i class="fa fa-check text-primary"></i>
                                                                            </a>
                                                                        </td>
                                                                        <td>
                                                                            <a href="<?php echo e(url('requests/update/'. $request->id , -1 )); ?>" style="cursor: pointer;font-size: 20px" class="text-danger">
                                                                                <i class="fa fa-trash"></i>
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end about -->
    <!-- Javascript files-->
    <script src="<?php echo e(asset('js/employee/jquery-3.0.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/employee/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/employee/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/employee/plugin.js')); ?>"></script>
    <!-- sidebar -->
    <script src="<?php echo e(asset('js/employee/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/employee/custom.js')); ?>"></script>


    <script>
        $(document).ready(function() {

            //READ NUM OF NOTIFICATIONS BY AJAX FOR HEAD
            function getHeadNotifications(){
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('getNewNotificationsNumberHead')); ?>",
                    success: function(response){
                        $('#notification-counter-head').html(response)
                    },
                    error: function(error){
                        $('#notification-counter-head').html(0)
                    }
                })
            }
            getHeadNotifications();

            window.setInterval(function(){
                getHeadNotifications();
            }, 5000);


            //READ NUM OF NOTIFICATIONS BY AJAX FOR USER
            function getUserNotifications(){
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('getNewNotificationsNumberUser')); ?>",
                    success: function(response){
                        $('#notification-counter-user').html(response)
                    },
                    error: function(error){
                        $('#notification-counter-user').html(0)
                    }
                })
            }
            getUserNotifications();

            window.setInterval(function(){
                getUserNotifications();
            }, 5000);



            //SEND LEAVE REQUEST BY AJAX

            $('#leaverequest').on('submit' , function(e){
                e.preventDefault();

                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('requests.store')); ?>",
                    data: $('#leaverequest').serialize(),
                    success: function(response){
                        alert('Request Send !');
                        $('#reason').val('')
                        $('.close').click();
                    },
                    error: function(error){
                        alert('Data Not send ' + error);
                    }
                })
            })



        });

        /*
            document.getElementById('leaverequest').addEventListener('submit' , postRequest);
                function postRequest(e){
                    e.preventDefault();
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST' , '<?php echo e(route('requests.store')); ?>' , true);
            xhr.onload = function(){
                alert(this.responseText);
            }
            xhr.send();
        }
        */
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/request/headcheckout.blade.php ENDPATH**/ ?>