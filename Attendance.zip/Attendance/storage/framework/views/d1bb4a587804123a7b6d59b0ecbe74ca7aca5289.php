<?php
    $route = 'attendances';

?>

<?php $__env->startSection('content'); ?>


    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">

                    <h3 style="padding: 20px">Attendance Hours </h3>

                    <select class="form-control centered col-md-6">
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>">
                            <?php echo e($department->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>

                <div class="card-body">

                    <?php if($users->count() > 0): ?>
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Department</th>
                                <th scope="col">Hours of Attendance</th>
                                <th scope="col">Hours of Absence</th>
                                <th scope="col">Head / Employee</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index +1); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td>
                                            <?php if($employees->count() > 0): ?>
                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($employee->user_id == $user->id): ?>
                                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($employee->department_id == $department->id): ?>
                                                                <?php echo e($department->name); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo e($hours_of_user_attendance[$user->id]); ?> / <?php echo e(date('d') * (14 - 9)); ?>

                                        </td>
                                        <td>
                                            <?php echo e((date('d') * (14 - 9)) - $hours_of_user_attendance[$user->id]); ?> / <?php echo e(date('d') * (14 - 9)); ?>

                                        </td>
                                        <td>
                                            <?php if($user->head == 0): ?>
                                                Employee
                                            <?php elseif($user->head == 1): ?>
                                                Head
                                            <?php endif; ?>
                                        </td>

                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/admin/attendance.blade.php.php ENDPATH**/ ?>
