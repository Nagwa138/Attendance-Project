

 <!-- Left side column. contains the logo and sidebar -->
 <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">


   <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset(auth()->user()->image_path)); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(strtoupper(auth()->user()->name)); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> <?php echo app('translator')->get('auth.online'); ?></a>
        </div>
      </div>

      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder=<?php echo app('translator')->get("site.search"); ?>>
          <span class="input-group-btn">
                <button type="submit" name="search"  class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->

      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">

        <li class="header"><?php echo app('translator')->get('site.MAIN NAVIGATION'); ?></li>

        <li class=" ">
          <a href="">
            <i class="fa fa-dashboard"></i> <span><?php echo app('translator')->get('site.dashboard'); ?></span>
          </a>
        </li>

        <li class="treeview  ">
          <a href="#">
            <i class="fa fa-users"></i>
            <span><?php echo app('translator')->get('site.users'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
                <small class="label pull-right bg-green">New</small>
              </span>
          </a>
          <ul class="treeview-menu">

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.index'); ?></a></li>

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.create'); ?> </a></li>

          </ul>

        </li>
        <li class=" treeview " >
         <a href="#">
           <i class="fa fa-th"></i>
           <span><?php echo app('translator')->get('site.categories'); ?></span>
           <span class="pull-right-container">
               <i class="fa fa-angle-left pull-right"></i>
               <small class="label pull-right bg-green">New</small>
             </span>
         </a>
         <ul class="treeview-menu ">

           <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.index'); ?></a></li>

           <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.create'); ?> </a></li>

         </ul>

        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-flag-o"></i>
            <span><?php echo app('translator')->get('site.courses'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
                <small class="label pull-right bg-yellow">New</small>
              </span>
          </a>
          <ul class="treeview-menu">

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.index'); ?></a></li>

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.create'); ?> </a></li>

          </ul>

        </li>
        <li class="treeview ">
          <a href="#">
            <i class="fa fa-question"></i>
            <span><?php echo app('translator')->get('site.asks'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
                <small class="label pull-right bg-yellow">New</small>
              </span>
          </a>
          <ul class="treeview-menu">

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.index'); ?></a></li>

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.create'); ?> </a></li>

          </ul>

        </li>

        <li class="treeview ">
          <a href="#">
            <i class="fa fa-bookmark-o"></i>
            <span><?php echo app('translator')->get('site.revisions'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
                <small class="label pull-right bg-yellow">New</small>
              </span>
          </a>
          <ul class="treeview-menu">

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.index'); ?></a></li>

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.create'); ?> </a></li>

          </ul>

        </li>
        <li class="treeview ">
          <a href="#">
            <i class="fa fa-users"></i>
            <span><?php echo app('translator')->get('site.students'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
                <small class="label pull-right bg-red">New</small>
              </span>
          </a>
          <ul class="treeview-menu">

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.index'); ?></a></li>

            <li><a href=""><i class="fa fa-circle-o"></i> <?php echo app('translator')->get('site.create'); ?> </a></li>

            <li><a href=""><i class="fa fa-recycle"></i> <?php echo app('translator')->get('site.trash'); ?> </a></li>


          </ul>

        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Charts</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/charts/chartjs.html"><i class="fa fa-circle-o"></i> ChartJS</a></li>
            <li><a href="pages/charts/morris.html"><i class="fa fa-circle-o"></i> Morris</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Flot</a></li>
            <li><a href="pages/charts/inline.html"><i class="fa fa-circle-o"></i> Inline charts</a></li>
          </ul>
        </li>

      </ul>



   </section>
   <!-- /.sidebar -->
  </aside>

<?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/employee/layout/sidebar.blade.php ENDPATH**/ ?>