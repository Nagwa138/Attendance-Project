<?php
    $route = 'employees';

?>


<?php $__env->startSection('content'); ?>
    <!---start container--->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <div class="card" style="padding: 15px">
                    <div class="card-header row justify-content-center centered">
                        <h2 >Profile Data </h2>
                    </div>

                    <div class="card-body row justify-content-center align-items-center">
                        <div class="col-md-6 col-sm-12" >
                            <div>
                                <span style="font-weight: bold">Employee  :</span>  <?php echo e($user->name); ?>

                            </div>
                            <br>
                            <div>
                                <span style="font-weight: bold">Email Address :</span> <?php echo e($user->email); ?>

                            </div>
                            <br>
                            <div>
                                <span style="font-weight: bold">Role :</span>
                                <?php if($user->head == 1): ?>
                                    <span>Head of Department</span>
                                <?php elseif($user->head == 0): ?>
                                    <span>Employee</span>
                                <?php endif; ?>
                            </div>
                            <br>
                            <div>
                                <span style="font-weight: bold"> Department :</span>
                                <?php if($employees->count() > 0): ?>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($departments->count() > 0): ?>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($employee->user_id == $user->id): ?>
                                                    <?php if($department->id == $employee->department_id): ?>
                                                        <?php echo e($department->name); ?>

                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <?php if($employees->count() > 0): ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->user_id == $user->id): ?>
                                        <img src="<?php echo e(asset('uploads/users_images/'.$user->id .'/'. $employee->pic)); ?>">
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="card-footer row justify-content-center centered">
                        <a href="<?php echo e(url('employees/destroy' , $user->id)); ?>" style="cursor: pointer; margin-right: 20px">
                            <button class="btn bg-success text-light" style="cursor: pointer">
                                Remove
                            </button>
                        </a>
                        <?php if($user->head == 0): ?>
                            <a href="<?php echo e(url('employees/update' , $user->id)); ?>" style="cursor: pointer">
                                <button class="btn bg-primary text-light" style="cursor: pointer">
                                    Make him Head
                                </button>
                            </a>
                        <?php elseif($user->head == 1): ?>
                            <a href="<?php echo e(url('employees/update' , $user->id)); ?>" style="cursor: pointer">
                                <button class="btn btn-outline-primary" style="cursor: pointer">
                                    Back To Employee
                                </button>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end container -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/employee/view.blade.php ENDPATH**/ ?>