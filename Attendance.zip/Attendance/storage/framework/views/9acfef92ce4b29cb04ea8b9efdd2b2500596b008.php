<?php $__env->startSection('content'); ?>

    <!----  start container -->

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <div class="card">
                    <div class="card-header">
                        <h3>Notifications</h3>
                    </div>

                    <div class="card-body row justify-content-center align-items-center">
                        <?php if(Auth::user()->head == 1): ?>
                        <table class="table table-striped table-hover">
                            <thead>
                            <th>#</th>
                            <th>Name : </th>
                            <th>Department : </th>
                            <th>Reason :</th>
                            <th>Status : </th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index +1); ?></td>
                                    <td><?php echo e($request->user->name); ?></td>
                                    <td><?php echo e($request->user->employee->department->name); ?></td>
                                    <td><?php echo e($request->reason); ?></td>
                                    <td>
                                        <?php if($request->status == 0): ?>
                                            <a href="<?php echo e(url('employees/acceptRequestNotification' , $request->id)); ?>">
                                                <button type="button " class="btn btn-primary" >
                                                    Accept
                                                </button>
                                            </a>
                                            <a href="<?php echo e(url('employees/rejectRequestNotification' ,$request->id)); ?>">
                                                <button type="button" class="btn btn-dark" >
                                                    Reject
                                                </button>
                                            </a>
                                        <?php endif; ?>
                                        <?php if($request->status == 1): ?>
                                            Accepted
                                        <?php endif; ?>
                                        <?php if($request->status == -1): ?>
                                            Rejected
                                        <?php endif; ?>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                            <?php endif; ?>


                            <?php if(Auth::user()->head == 0): ?>
                                <table class="table table-striped table-hover">
                                    <thead>
                                    <th>#</th>
                                    <th>Reason :</th>
                                    <th>Status : </th>
                                    <th>Date : </th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index +1); ?></td>
                                            <td><?php echo e($request->user->name); ?></td>
                                            <td><?php echo e($request->user->employee->department->name); ?></td>
                                            <td><?php echo e($request->reason); ?></td>
                                            <td>
                                                <?php if($request->status == 0): ?>
                                                   Pending
                                                <?php endif; ?>
                                                <?php if($request->status == 1): ?>
                                                    Accepted
                                                <?php endif; ?>
                                                <?php if($request->status == -1): ?>
                                                    Rejected
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($request->created_at); ?></td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <!----  end container -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/employee/notifications.blade.php ENDPATH**/ ?>