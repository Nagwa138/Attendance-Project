<?php $__env->startSection('content'); ?>

    <!----  start container -->

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <div class="card">
                    <div class="card-header">
                        <h3>Request For Leaving from <?php echo e($user->name); ?></h3>
                    </div>

                    <div class="card-body row justify-content-center align-items-center">
                        <div class="col-md-6 ">
                            <div class="about-box">
                                <h4> Request : </h4>

                                    <span style="font-weight: bold"> Name :</span><br>
                                    <span><?php echo e($user->name); ?></span><br><br>
                                    <span style="font-weight: bold"> E-mail :</span><br>
                                    <span><?php echo e($user->email); ?></span><br><br>
                                    <span style="font-weight: bold"> Department :</span><br>
                                    <span><?php echo e($employee->department->name); ?></span><br><br>
                                    <span style="font-weight: bold"> Reason of Leaving :</span><br>
                                    <span><?php echo e($request->reason); ?></span><br>


                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 row justify-content-center centered">
                            <img src="<?php echo e(asset('uploads/users_images/' . $user->id .'/'. $employee->pic)); ?>">
                        </div>

                    </div>
                    <div id="options" class="card-footer">
                        <?php if( $notification->accept == 0): ?>
                        <a href="<?php echo e(url('employees/acceptRequest' , $notification->id)); ?>">
                            <button type="button " class="btn btn-primary" >
                                Accept
                            </button>
                        </a>
                        <a href="<?php echo e(url('employees/rejectRequest' ,$notification->id)); ?>">
                            <button type="button" class="btn btn-dark" >
                                Reject
                            </button>
                        </a>
                            <?php endif; ?>

                        <?php if( $notification->accept == 1): ?>
                            Accepted
                            <?php endif; ?>

                            <?php if( $notification->accept == -1): ?>
                                Rejected
                            <?php endif; ?>


                    </div>
                </div>
            </div>
        </div>
    </div>


    <!----  end container -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/employee/view_request.blade.php ENDPATH**/ ?>