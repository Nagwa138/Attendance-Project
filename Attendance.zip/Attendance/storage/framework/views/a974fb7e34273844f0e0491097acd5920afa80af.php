<html lang="en">

<head>

    <meta charset="utf-8" >
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" >
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo csrf_token(); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/apple-icon.png')); ?>">

    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.ico')); ?>">

    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <!--     Fonts and icons     -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">

    <!-- CSS Files -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/light-bootstrap-dashboard.css?v=2.0.0')); ?> " rel="stylesheet" />
    <!-- CSS Just for demo purpose, dont include it in your project -->
    <link href="<?php echo e(asset('css/demo.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/backend.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldContent('links'); ?>
    <style>

        a:hover{
            cursor: pointer;
        }
    </style>


</head>

<body>


    <div class="wrapper">
        <div class="sidebar" data-image="<?php echo e(asset('img/sidebar-5.jpg')); ?>">

            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(url('home')); ?>">
                            <i class="nc-icon nc-chart-pie-35"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>

                    


                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(route('employees.index')); ?>">
                            <i class="fa fa-users"></i>
                            <p>Employees</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('departments.index')); ?>">
                            <i class="fa fa-building"></i>
                            <p>Departments</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('requests.create')); ?>">
                            <i class="fa fa-hand-paper-o" aria-hidden="true"></i>
                            <p>Check out Requests</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('attendances.index')); ?>">
                            <i class="fa fa-handshake-o" aria-hidden="true"></i>
                            <p>Attendance</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('requests.index')); ?>">
                            <i class="fa fa-lightbulb-o" aria-hidden="true"></i>
                            <p>Join Requests</p>
                        </a>
                    </li>


                    <li class="nav-item active active-pro">
                        <a class="nav-link active" href="upgrade.html">
                            <i class="nc-icon nc-alien-33"></i>
                            <p>Upgrade to PRO</p>
                        </a>
                    </li>
                </ul>
            </div>


        </div>

        <?php echo $__env->make('Dashboard\Layout\navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('Dashboard\Layout\footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>
<?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/Layout/sidebar.blade.php ENDPATH**/ ?>