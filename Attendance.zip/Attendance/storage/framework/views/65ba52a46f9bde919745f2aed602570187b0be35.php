<?php
    $route = 'admins';

?>

<?php $__env->startSection('content'); ?>


    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    Notifications
                </div>

                <div class="card-body">

                    <table class="table table-striped table-hover">
                        <thead>
                        <th>#</th>
                        <th>Name : </th>
                        <th>Department : </th>
                        <th>Reason :</th>
                        <th>Status : </th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index +1); ?></td>
                                <td><?php echo e($request->user->name); ?></td>
                                <td><?php echo e($request->user->employee->department->name); ?></td>
                                <td><?php echo e($request->reason); ?></td>
                                <td>
                                    <?php if($request->status == 0): ?>
                                        <a href="<?php echo e(url('employees/acceptRequestNotification' , $request->id)); ?>" style="margin-right: 15px">
                                            <button type="button" class="btn bg-primary btn-sm text-light" >
                                                Accept
                                            </button>
                                        </a>
                                        <a href="<?php echo e(url('employees/rejectRequestNotification' ,$request->id)); ?>">
                                            <button type="button" class="btn bg-dark btn-sm text-light" >
                                                Reject
                                            </button>
                                        </a>
                                    <?php endif; ?>
                                        <?php if($request->status == 1): ?>
                                            Accepted
                                        <?php endif; ?>
                                        <?php if($request->status == -1): ?>
                                            Rejected
                                        <?php endif; ?>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/admin/notifications.blade.php ENDPATH**/ ?>