<?php $__env->startSection('content'); ?>

    <!----  start container -->

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <div class="card">
                    <div class="card-header">
                        <h3>Attence Hours </h3>

                    </div>

                    <div class="card-body">

                        <?php if($users->count() > 0): ?>
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Department</th>
                                    <th scope="col">Hours of Attendance</th>
                                    <th scope="col">Hours of Absence</th>
                                    <th scope="col">Head / Employee</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if($employees->count() > 0): ?>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->user_id != Auth::user()->id): ?>
                                    <?php if($employee->user_id == $user->id): ?>

                                    <tr>
                                        <td><?php echo e($index +1); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td>



                                                                <?php echo e($employee->department->name); ?>



                                        </td>
                                        <td>
                                            <?php echo e($hours_of_user_attendance[$user->id]); ?> / <?php echo e(date('d') * (14 - 9)); ?>

                                        </td>
                                        <td>
                                            <?php echo e((date('d') * (14 - 9)) - $hours_of_user_attendance[$user->id]); ?> / <?php echo e(date('d') * (14 - 9)); ?>

                                        </td>
                                        <td>
                                            <?php if($user->head == 0): ?>
                                                Employee
                                            <?php elseif($user->head == 1): ?>
                                                Head
                                            <?php endif; ?>
                                        </td>

                                    </tr>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!----  end container -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/employee/attendance.blade.php ENDPATH**/ ?>