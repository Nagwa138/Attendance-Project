<?php
    $route = 'requests';

?>

<?php $__env->startSection('content'); ?>


    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">

                    <h3 style="padding: 20px">Check Out Requests</h3>


                </div>

                <div class="card-body">

                    <?php if($users->count() > 0): ?>
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Department</th>
                                <th scope="col">Reason</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if($requests->count() > 0): ?>
                                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->id == $request->user_id): ?>
                                        <tr>
                                            <td><?php echo e($index +1); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td>
                                                <?php if($employees->count() > 0): ?>
                                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($employee->user_id == $user->id): ?>
                                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($employee->department_id == $department->id): ?>
                                                                    <?php echo e($department->name); ?>

                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($request->reason); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(url($route . '/update/'. $request->id , 1 )); ?>" style="cursor: pointer;font-size: 20px">
                                                    <i class="fa fa-check"></i>
                                                </a>
                                            </td>

                                            <td>
                                                <a href="<?php echo e(url($route . '/update/'. $request->id , -1 )); ?>" style="cursor: pointer;font-size: 20px" class="text-danger">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/request/checkout.blade.php ENDPATH**/ ?>