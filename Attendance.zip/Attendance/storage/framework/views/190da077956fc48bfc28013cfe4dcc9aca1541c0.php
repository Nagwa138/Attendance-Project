<?php
    $route = 'departments';

?>

<?php $__env->startSection('content'); ?>


    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route($route. '.create')); ?>">
                        <button class="btn bg-primary text-light">Add</button>
                    </a>
                </div>

                <div class="card-body">
                    <?php if($departments->count() > 0): ?>

                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Department</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($index +1); ?></td>
                            <td><?php echo e($department->name); ?></td>
                            <td>
                                <a href="<?php echo e(url('departments/destroy' ,$department->id )); ?>" class="text-danger">Delete</a>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/department/index.blade.php ENDPATH**/ ?>