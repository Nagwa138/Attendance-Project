<div class="main-panel">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg " color-on-scroll="500">
        <div class="container-fluid">
            <?php if(auth()->guard()->check()): ?>
                <a class="navbar-brand" href="<?php echo e(url('home')); ?>"> Home </a>
                <a class="navbar-brand" href="<?php echo e(url('employees/create')); ?>" style="margin-left: 20px;margin-right: 20px">
                    <i class="fa fa-user-circle" aria-hidden="true"></i>
                </a>

            <?php endif; ?>
            <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-bar burger-lines"></span>
                <span class="navbar-toggler-bar burger-lines"></span>
                <span class="navbar-toggler-bar burger-lines"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navigation">
                <!--Right List-->
                <ul class="nav navbar-nav mr-auto align-items-center">

                    <li class="nav-item">
                        <a href="<?php echo e(url('/')); ?>" class="nav-link" data-toggle="dropdown">
                            <i class="nc-icon nc-palette"></i>
                            <span class="d-lg-none">Attendance</span>
                        </a>
                    </li>

                    <li class="dropdown nav-item">
                        <a  id="admin_new_notification_viewer" class="dropdown-toggle nav-link" data-toggle="dropdown">
                            <i class="nc-icon nc-planet"></i>
                            <?php if(Auth::guard('admin')->check()): ?>
                                <span class="notification" id="notification-counter-admin"></span>
                            <?php endif; ?>

                            <span class="d-lg-none">Notification</span>
                        </a>

                        
                        <?php if(Auth::guard('admin')->check()): ?>
                            <ul class="dropdown-menu" id="admin-notification-menu" style="padding:20px;list-style:decimal">

                                <a class="dropdown-item text-primary" data-toggle="modal" data-target="#notificationmodel">
                                    View All Notifications
                                </a>

                            </ul>
                        <?php endif; ?>


                    </li>
                            <!-- Modal -->
                            <div class="modal fade" id="notificationmodel" tabindex="-1" role="dialog" aria-labelledby="notificationmodelLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                <div class="modal-content" >
                                    <div class="modal-header">
                                    <h5 class="modal-title text-dark" id="notificationmodelLabel">NOTIFICATIONS</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                                    <div class="modal-body">
                                        
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn bg-primary text-light" style="cursor: pointer" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                                </div>
                            </div>

                </ul>

                <div class="search" style="position: relative; top: 22px;">


                   </div>


                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->

                    <?php if(Auth::guard('admin')->check()): ?>


                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::guard('admin')->user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(url('logoutAdmin')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(url('logoutAdmin')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>

                    <?php elseif(Auth::user()): ?>

                        <li>
                            <img src="<?php echo e(Auth::user()->image_path); ?>" class="image-user" style="margin:21px 0px;">

                        </li>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>

                    <?php else: ?>

                    <?php if(auth()->guard()->guest()): ?>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>

                </ul>


            </div>
        </div>
    </nav>

    <div class="content ">
        <div class="container-fluid">
            <div class="row">

                <div class="col-md-12">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>


    </div>

</div>

    <!-- End Navbar -->
<?php /**PATH E:\Laravel Projects\Attendance\resources\views/Dashboard\Layout\navbar.blade.php ENDPATH**/ ?>