<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" >
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" >
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo csrf_token(); ?>">
    <title><?php echo e(config('app.name', 'Attendance')); ?></title>

    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/apple-icon.png')); ?>">

    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.ico')); ?>">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo csrf_token(); ?>">

    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <!--     Fonts and icons     -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">

    <!-- CSS Files -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <!-- site metas -->
    <title>Home</title>
    <!-- style css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/employee/style.css')); ?>">
    <!-- Responsive-->
    <link rel="stylesheet" href="<?php echo e(asset('css/employee/responsive.css')); ?>">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/employee/jquery.mCustomScrollbar.min.css')); ?>">
</head>
<!-- body -->
<body class="main-layout">
<?php echo $__env->make('dashboard.Layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="about">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 style="padding: 20px">Attendance Hours of <?php echo e($department->name); ?> Department</h3>
                    </div>
                    <div class="card-body">
                        <?php if($users->count() > 0): ?>
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Hours of Attendance</th>
                                    <th scope="col">Hours of Absence</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->id != Auth::user()->id): ?>
                                    <tr>
                                        <td><?php echo e($index +1); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td>
                                            <?php if(isset($hours_of_user_attendance[$user->id])): ?>
                                            <?php echo e($hours_of_user_attendance[$user->id]); ?> / <?php echo e(date('d') * (14 - 9)); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(isset($hours_of_user_attendance[$user->id])): ?>
                                            <?php echo e((date('d') * (14 - 9)) - $hours_of_user_attendance[$user->id]); ?> / <?php echo e(date('d') * (14 - 9)); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end about -->
<!-- Javascript files-->
<script src="<?php echo e(asset('js/employee/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/employee/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/employee/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/employee/jquery-3.0.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/employee/plugin.js')); ?>"></script>
<!-- sidebar -->
<script src="<?php echo e(asset('js/employee/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/employee/custom.js')); ?>"></script>
</body>
</html>
<?php /**PATH E:\Laravel Projects\Attendance\resources\views/dashboard/request/attendance_department.blade.php ENDPATH**/ ?>